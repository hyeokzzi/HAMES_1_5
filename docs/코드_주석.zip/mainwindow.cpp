#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "wiringPi.h"
#include "wiringPiSPI.h"
#include "wiringSerial.h"
#include "softPwm.h"

int UserMode_state = 0;
int Cover_state =0;
int Value =0;

// value 
int gPir = 0;               // 인체 감지
int gUwave = 0;             // 초음파 sensor, window와 차량 프레임까지의 거리(cm)
int gUwave2 = 0;            // 초음파 sensor, cover와 차량 프레임까지의 거리(cm)
int gRain = 0;              // 빗물 감지 sensor value (아날로그)
double gGyroX = 0.0;        // 자이로 sensor, 차체 기울기 감지 (X축, pitch)
double gGyroY = 0.0;        // 자이로 sensor, 차체 기울기 감지 (Y축, roll)
int gJoystick = 0;          // window 조작용 조이스틱 sensor value(아날로그)
int gOpenButton = 0;        // Cover가 열리는 것을 인식하는 Button 값
int gCloseButton = 0;       // Cover가 닫히는 것을 인식하는 Button값

// 각각 cover와 window가 이동 가능한 상태인지 판별. 기본은 멈춤 상태. (0: 이동 가능, 1: 멈춤)
int g_stop_moving_cover = 1;
int g_stop_moving_window = 1;

// init State, 초기 상태
int gWindowState = 0;       // window 초기 상태 (CLOSE)
int gCoverState = 0;        // cover 초기 상태 (CLOSE)
int gOpenDegree = 0;        // window가 열린 길이 / window 프레임 길이 * 100 (0 ~ 100의 백분율로 나타냄)
int gLED = 0;               // LED on(1)/off(0)
int gUserMode = 0;          // user mode 여부 판별, 0: smart mode, 1: user mode

int cnt = 0;                // 어디에 사용된 건지 찾을 수 없음 (cnt_loop나 다른 것으로 대체된 듯)
int prev_value = 0;         // 상동


// MainWindow UI Widget과 코드 연결
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);      // UI에 있는 버튼 연결
    IsClicked1 = false;
    IsClicked2 = false;
    IsClicked3 = false;
    wiringPiSetup();        //WiringPi 사용 세팅
    wiringPiSetupGpio();

    ui->Select_groupBox->setHidden(1);
    ui->Cover_groupBox->setHidden(1);
    QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_0.png");
    ui -> label_image -> setPixmap(pix);


    // Create Thread Object and Connect Signal/Slot
    // 각 센서들을 thread에 배치하여 동시에 데이터 센싱을 진행하도록 함
    // thread 목록 : MPU(자이로), PIR(인체 감지), Rain(빗물 감지), UWAVE(초음파), Logic(센서 데이터 처리 로직)
    mpu_thread = new MPU_Sensor(this);
    mpu_thread->start();

    pir_thread = new PIR_Sensor(this);
    pir_thread->start();

    rain_thread = new Rain_Sensor(this);
    rain_thread->start();

    uwave_thread = new UWAVE_Sensor(this);
    uwave_thread->start();

    logic_thread = new Logic(this);
    logic_thread->start();
}

// MainWindow 종료 시 thread 종료하여 메모리 반환
MainWindow::~MainWindow()
{
    mpu_thread->stop();
    pir_thread->stop();
    rain_thread->stop();
    uwave_thread->stop();
    logic_thread->stop();
    delete ui;
}

///////////////////////////////////////////////////////////
// QT Mainwindow UI에서 mode 버튼 클릭 시 이벤트

// User mode : 
void MainWindow::on_userMode_clicked()
{
    // set ui
    ui->Select_groupBox->setHidden(1);
    ui->Cover_groupBox->setHidden(1);
    UserMode_state = !UserMode_state;

    gUserMode = UserMode_state; // set

    if(UserMode_state == 0){
        ui->Mode_groupBox->setEnabled(1);
        ui->label_image->setEnabled(1);
        QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_0.png");
        ui -> label_image -> setPixmap(pix);
    }
    else if(UserMode_state == 1){

      ui->Mode_groupBox->setDisabled(1);
      ui->label_image->setDisabled(1);
    }
}

// Auto mode : 센서들의 데이터를 이용하여 자동으로 썬루프 제어
void MainWindow::on_AutoMode_clicked()
{
    // set variable
    gCoverState = OPEN;
    gWindowState = OPEN;
    g_stop_moving_cover = 0;
    g_stop_moving_window = 0;
    gOpenDegree = 100;

    // set ui
     ui->Select_groupBox->setHidden(1);
     ui->Cover_groupBox->setHidden(1);
     QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_100.png");
     ui -> label_image -> setPixmap(pix);
}

// Refresh mode : 자동 동작, cover는 전부 open, window는 20% 만큼 open
void MainWindow::on_RefreshMode_clicked()
{
    // set variable
    gCoverState = OPEN;
    gWindowState = OPEN;
    g_stop_moving_cover = 0;
    g_stop_moving_window = 0;
    gOpenDegree = 20;

     ui->Select_groupBox->setHidden(1);
     ui->Cover_groupBox->setHidden(1);
     QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_20.png");
     ui -> label_image -> setPixmap(pix);
}

// Light mode : 자동 동작, cover는 전부 open, window는 전부 close, LED on
void MainWindow::on_LightMode_clicked()
{
    // set variable
    gCoverState = OPEN;
    gWindowState = CLOSE;
    g_stop_moving_cover = 0;
    g_stop_moving_window = 0;
    gOpenDegree = 100;

     ui->Select_groupBox->setHidden(1);
     ui->Cover_groupBox->setHidden(1);
     QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_light.png");
     ui -> label_image -> setPixmap(pix);
}

// Select mode : 직접 썬루프를 제어할 수 있게 UI 내의 window와 cover버튼 접근 권한 부여(enable)
void MainWindow::on_SelectMode_clicked()
{
    // set variable

     ui->Cover_groupBox->setVisible(1);
     ui->Select_groupBox->setVisible(1);
     ui ->Select_groupBox->setDisabled(1);
     QPixmap pix("/home/pi/HAMES_1_5/qt_file/temp/image/car_100.png");
     ui -> label_image -> setPixmap(pix);
}

// QT UI 내의 cover 버튼을 클릭하면 open 되어있던 cover는 close, close 되어있던 cover는 open
void MainWindow::on_Btn_cover_clicked()
{
    Cover_state = !Cover_state;
    if(Cover_state == 1){
        ui->Select_groupBox->setEnabled(1);
    }
    else if(Cover_state == 0){
        ui ->Select_groupBox->setDisabled(1);
        ui->WindowSlider->setValue(0);
    }
}

// QT UI 내의 Slider를 움직이면 해당 슬라이더가 움직인 비율만큼(백분율) string 값 받아옴
void MainWindow::on_WindowSlider_valueChanged(int value)
{
    QString string = QString::number(value);
}

// 위 함수에서 받아온 string 값만큼 window open
void MainWindow::on_WindowSlider_sliderReleased()
{
    // set variable
    gCoverState = OPEN;
    gWindowState = OPEN;
    g_stop_moving_cover = 0;
    g_stop_moving_window = 0;
    gOpenDegree =ui->WindowSlider->value();
}

