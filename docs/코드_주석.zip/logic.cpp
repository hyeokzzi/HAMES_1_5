#include "logic.h"
#include "mainwindow.h"
#include "gpio.h"

// Get value from each sensor, 센서로부터 받아들이는 값
// extern - mainwindow.cpp
extern int gPir;
extern int gUwave;
extern int gUwave2;
extern int gRain;
extern double gGyroX;
extern double gGyroY;
extern int gJoystick;
extern int gOpenButton;
extern int gCloseButton;

extern int g_stop_moving_cover;
extern int g_stop_moving_window;

extern int gWindowState;
extern int gCoverState;
extern int gOpenDegree;
extern int gLED;
extern int gUserMode;

Logic::Logic(QObject *parent) : QThread(parent)
{
    pre_detected = 0;       // 
    tmp_detected = 0;       // 
    pre_dist = 0;           // 

    gWindowState = OPEN;    // 현재 window 상태 , OPEN/CLOSE
    gCoverState = OPEN;     // 현재 cover 상태 , OPEN/CLOSE
    gOpenDegree = 100;      // window의 열린 정도 (0~100)
    gLED = 0;               // LED 작동 여부 (0: off, 1: on)
    gUserMode = 0;          // user mode 판별(0: smart mode, 1: user mode)

    fd = serialOpen("/dev/ttyACM0",9600); // 9600번 Serial port를 open한다.
    serialPutchar(fd,'x'); // Seiral 통신을 통해 아두이노로 x라는 unsigned char x를 보낸다. 통신이 이루어지는지 확인하기 위함.
}

void Logic::run()
{
    // stopFlag가 들어오기 전까지
    while(!m_stopFlag)
    {
        int msg = 0b00000000; //Serial 통신으로 보낼 메세지.
        /*
        이후 2진수 int msg를 16진수로 변환시킨 다음, unsigned char(0 ~ F)로 치환하여 전송하게 된다. 0b 00000000의 각 자리값은 다음과 같다.
        0b *0000000 : 정보 없음. 더미값이므로 0으로 고정
        0b 0*000000 : 정보 없음. 더미값이므로 0으로 고정
        0b 00*00000 : window와 연결된 모터 작동 여부. (0: 모터 중지, 1: 모터 작동)
        0b 000*0000 : window와 연결된 모터 방향. (0: 시계 방향 회전, 1: 반시계 방향 회전)
        0b 0000*000 : cover와 연결된 모터 작동 여부. (0: 모터 중지, 1: 모터 작동)
        0b 00000*00 : cover와 연결된 모터 방향. (0: 시계 방향 회전, 1: 반시계 방향 회전)
        0b 000000*0 : 정보 없음. 더미값이므로 0으로 고정
        0b 0000000* : 정보 없음. 더미값이므로 0으로 고정
        */


       // 디버그 창에서 window OPEN/CLOSE 상태, cover OPEN/CLOSE 상태를 출력하기 위함
        if (gWindowState == OPEN)
             // 만약 window가 열린 상태라면 debug창에 "gWindowState = open" 메세지 출력
            qDebug() << QString("gWindowState = open");
        else
            qDebug() << QString("gWindowState = close");

        if (gCoverState == OPEN)
            qDebug() << QString("gCoverState = open");
        else
            qDebug() << QString("gCoverState = close");

        // g_stop_moving_window, g_stop_moving_cover 값이 정상적으로 들어오는지 확인하기 위함
        qDebug() << QString("g_stop_moving_window = ") << g_stop_moving_window;
        qDebug() << QString("g_stop_moving_cover = ") << g_stop_moving_cover;

        /////////////////////////////////////////////////////
        // 조이스틱 설정
        /*
        조이스틱을 위로 올린다      : window open
        조이스틱을 아래로 내린다    : window close
        조이스틱을 누른다           : cover open
        */

        // 조이스틱 값이 3000 미만이라면 조이스틱을 위로 올린 것으로 판단, window open
        qDebug() << QString("gJoystick = ") << gJoystick;
        if (gJoystick < 3000) // up, open
        {
            qDebug() << QString("!!! Joystick OPEN !!!"); // debug창 출력

            // 만약 cover가 열려있지 않은 상태라면 cover부터 open한 다음에 window open
            // g_stop_moving_cover 변수 값을 0으로 줘서 이동 가능함을 알린다.
            if (gCoverState != OPEN) // Cover
            {
                gCoverState = OPEN;
                g_stop_moving_cover = 0;
            }

            // 만약 cover는 열려있고 window는 열려있지 않은 상태라면 바로 window open
            // g_stop_moving_window 변수 값을 0으로 줘서 이동 가능함을 알린다.
            if (gWindowState != OPEN) // Window
            {
                gWindowState = OPEN;
                g_stop_moving_window = 0;
            }
        }

        // 조이스틱 값이 3000이상, 3700미만이라면 조이스틱에 아무런 조작이 가해지지 않은 것으로 판단
        else if (gJoystick < 3700)
        {
            /* do nothing */
        }

        // 조이스틱 값이 3700 이상이라면 조이스틱을 아래로 내린 것으로 판단, window close
        else if (gJoystick >= 3700) // down, close
        {
            qDebug() << QString("!!! Joystick CLOSE !!!"); // debug창 출력

            if (gCoverState != CLOSE) // Cover
            {
                gCoverState = CLOSE;
                g_stop_moving_cover = 0;
            }
            if (gWindowState != CLOSE) // Window
            {
                gWindowState = CLOSE;
                g_stop_moving_window = 0;
            }
        }
        /////////////////////////////////////////////////////

        /////////////////////////////////////////////////////
        // User mode 로직 set
        // gUserMode = 0 이라면 Smart mode - 센서 인식을 통해 자동으로 썬루프 open/close
        if (gUserMode == 0)
        {
            // motor 동작 set

            // [rainClose] 0: 빗물 감지되지 않음, 1: 빗물이 감지되므로 window를 닫아줘야 함.
            // 만약 빗물 센서로부터 window를 닫으라는 명령이 들어온다면
            if (rainClose() == 1)
            {
                qDebug() << QString("!!! RAIN !!!");
                gWindowState = CLOSE; // window close (cover는 open 상태)
                g_stop_moving_window = 0; // window 이동 가능하게 set
            }

            // [gyroClose] 0: 차체 기울기가 안전 범위 내, 1: 차체 기울기가 안전 범위를 벗어났으므로 window를 닫아줘야 함.
            // 만약 기울기 센서로부터 window를 닫으라는 명령이 들어온다면 window, cover close. window 이동 가능하게 set
            if (gyroClose() == 1)
            {
                qDebug() << QString("!!! GYRO !!!");
                gWindowState = CLOSE;
                gCoverState = CLOSE;
                g_stop_moving_window = 0;
            }

            // buzzer
            // pirUwaveBuzzer()로부터 1값을 return 받을 때 buzzer를 울리도록 set (msg에 buzzer bit set)
            if (pirUwaveBuzzer() == 1)
            {
                qDebug() << QString("!!! BUZZER !!!");
                msg += (1 << BUZZER);
            }
        }

        /////////////////////////////////////////////////////
        // Motor Control
        // debug용 출력
        qDebug() << QString("gOpenButton = ") << gOpenButton;
        qDebug() << QString("gCloseButton = ") << gCloseButton;
        qDebug() << QString("UWAVE = ") << gUwave;

        qDebug() << QString("==========================================");

        // cover close, window close라면 둘 다 닫아줘야 하므로 cover를 닫은 후에 window를 닫는다.
        if ((gCoverState == CLOSE) && (gWindowState == CLOSE))
        {
            qDebug() << QString("Case 1");
            if (g_stop_moving_window == 1) msg = coverClose(msg); // Window already closed
            else msg = windowClose(msg);
        }

        // cover open, window close라면 cover를 연 뒤에 window를 닫는다.
        else if ((gCoverState == OPEN) && (gWindowState == CLOSE))
        {
            qDebug() << QString("Case 2");
            if (g_stop_moving_cover == 1) msg = windowClose(msg); // Cover already opened
            else msg = coverOpen(msg);
        }

        // cover close, window open이라면 오류 메세지를 띄운다. (cover가 열리지 않고 window만 열릴 수는 없다.)
        else if ((gCoverState == CLOSE) && (gWindowState == OPEN))
        {
            /* WARNING */
            qDebug() << QString("Case 3");
        }

        // cover open, window open이라면 cover를 연 뒤에 window를 연다.
        else if ((gCoverState == OPEN) && (gWindowState == OPEN))
        {
            qDebug() << QString("Case 4");
            if (g_stop_moving_cover == 1) msg = windowOpen(msg); // Cover already opened
            else msg = coverOpen(msg);
        }

        // if문 마무리
        else
        {
            /* do nothing */
        }

        // msg를 아두이노로 전송한다.
        printMsg(msg);
        serialPutchar(fd, msg);
        emit ThreadEnd(msg);

       sleep(1);
    }

}

// msg 확인용 debug 출력
void Logic::printMsg(int msg)
{
    QString string;
    string += QString::number((msg & 0b00100000) >> 5);
    string += QString::number((msg & 0b00010000) >> 4);
    string += QString::number((msg & 0b00001000) >> 3);
    string += QString::number((msg & 0b00000100) >> 2);
    string += QString::number((msg & 0b00000010) >> 1);
    string += QString::number(msg & 0b00000001);
    string += " : MESSAGE\n"; 
    qDebug() << string;
}

// cover가 이동 가능(g_stop_moving_cover == 0)하고 초음파 센서가 감지한 썬루프 프레임까지의 거리(gUwave2)가 OPEN 상태라면 cover move bit(1)를 msg에 입력한다. (direction은 기본 set인 0) 만약 조건을 만족하지 않으면 cover가 이동하지 못하도록 한다(g_stop_moving_cover = 1).
int Logic::coverClose(int msg)
{
    if ((g_stop_moving_cover == 0) && ((gUwave2 > CLOSE_LENGTH) && (gUwave2 < 80)))
    {
        msg += (1 << COVER_SET); // cw, cover close
    }
    else
    {
        g_stop_moving_cover = 1;
    }
    return msg;
}

// cover가 이동 가능(g_stop_moving_cover == 0)하고 초음파 센서가 감지한 썬루프 프레임까지의 거리(gUwave2)가 CLOSE 상태라면 cover move bit(1)와 cover direction bit(1)를 msg에 입력한다. 만약 조건을 만족하지 않으면 cover가 이동하지 못하도록 한다(g_stop_moving_cover = 1).
int Logic::coverOpen(int msg)
{
    if ((g_stop_moving_cover == 0) && ((gUwave2 < OPEN_LENGTH) || (gUwave2 > 80)))
    {
        msg += (1 << COVER_SET);
        msg += (1 << COVER_DIR); // ccw, cover open
    }
    else
    {
        g_stop_moving_cover = 1;
    }
    return msg;
}

// window가 이동 가능(g_stop_moving_window == 0)하고 초음파 센서가 감지한 썬루프 프레임까지의 거리(gUwave)가 OPEN 상태라면 window move bit(1)와 window direction bit(1)를 msg에 입력한다. 만약 조건을 만족하지 않으면 window가 이동하지 못하도록 한다(g_stop_moving_window = 1).
int Logic::windowClose(int msg)
{
    if ((g_stop_moving_window == 0) && ((gUwave > CLOSE_LENGTH) && (gUwave < 80)))
    {
        msg += (1 << WINDOW_SET);
        msg += (1 << WINDOW_DIR); // ccw, window close
    }
    else
    {
        g_stop_moving_window = 1;
    }
    return msg;
}

// window가 이동 가능(g_stop_moving_window == 0)하고 초음파 센서가 감지한 썬루프 프레임까지의 거리(gUwave)가 CLOSE 상태라면 window move bit(1)를 msg에 입력한다. (direction은 기본 set인 0) 만약 조건을 만족하지 않으면 window가 이동하지 못하도록 한다(g_stop_moving_window = 1). 이때, 현재 window가 열려있는 만큼의 거리를 OPEN LENGTH로부터 제외하여 margin을 계산, window가 프레임과 충돌하지 않도록 조절한다.
int Logic::windowOpen(int msg)
{
    int th = gOpenDegree / 100.0 * OPEN_LENGTH;
    qDebug() << QString("th = ") << th;

    if ((g_stop_moving_window == 0) && ((gUwave < th - MARGIN) || (gUwave > 80)))
    {
        msg += (1 << WINDOW_SET); // cw, window open
    }
    else if ((g_stop_moving_window == 0) && ((gUwave > th + MARGIN) || (gUwave > 80)))
    {
        msg += (1 << WINDOW_SET);
        msg += (1 << WINDOW_DIR); // ccw, window close
    }
    else
    {
        g_stop_moving_window = 1;
    }
    return msg;
}

// 차체 기울기가 x, y축으로 모두 10 이상 기울어지면 window close 요청을 보낸다.
int Logic::gyroClose()
{
    int res = 0;
    if(gGyroX >= 10 || gGyroX <= -10 || gGyroY >= 10 || gGyroY <= -10){
    	if(gUwave){	//gUwave logic required 
    		res = 1;	//close 
		}
	}
    return res;
}

// 빗물이 감지되면 window close 요청을 보낸다.
int Logic::rainClose()
{
    int res = 0;

    if (gRain < RAIN_TH) res = 1;
    else res = 0;

    return res;
}

// 프레임과 간의 거리가 CLOSE_LENGTH 이내가 되면 멈춤 요청을 보낸다.
int Logic::uwaveClose()
{
    int res = 0;

    if (gUwave < CLOSE_LENGTH) res = 0;
    else res = 1;

    return res;
}

// 이 아래 두 함수는 이해가 안 돼서 패스ㅠ
int Logic::pirUwaveBuzzer()
{
    int res = 0;

    if (gUwave < 80) // trash value filtering
    {
        if (Q.size() == MAX_Q_SIZE) Q.pop_front();
        Q.push_back(gUwave);
    }

    tmp_detected = gPir;

    if ((pre_detected == 0) && (tmp_detected == 1))
    {
        double stdev = calcStdev();

        if (stdev > DIST_STDEV_TH) res = 1;
        else res = 0;
    }

    pre_detected = tmp_detected;
    pre_dist = gUwave;

    return res;
}


double Logic::calcStdev()
{
    double sum1 = 0;
    double sum2 = 0;
    double avg = 0;
    double var = 0;
    double stdev = 0;

    for (int i = 0; i < Q.size(); i++)
    {
        sum1 += Q[i];
    }
    avg = sum1 / static_cast<double>(Q.size());

    for (int i = 0; i < Q.size(); i++)
    {
        sum2 += pow((Q[i] - avg), 2);
    }
    var = sum2 / static_cast<double>(Q.size() - 1);
    stdev = sqrt(var);

    return stdev;
}

void Logic::stop()
{
    m_stopFlag = true;
}
