// 인체 감지 센서가 열린 window와 차체 프레임 사이에서 인체를 감지하면 손끼임 방지를 위해 window의 움직임을 멈춘다.

#include "pir_sensor.h"
#include "mainwindow.h"
#include "gpio.h"

extern int gPir;
extern int gOpenButton;
extern int gCloseButton;

PIR_Sensor::PIR_Sensor(QObject *parent) : QThread(parent)
{
   pinMode(PIR_GPIO_IN, INPUT);
   pinMode(OPEN_BTN_GPIO, INPUT);
   pinMode(CLOSE_BTN_GPIO, INPUT);
}

// PIR 센서 thread를 동작시켜 (1)PIR 센서 값과 (2)프레임 양측에 달린 window OPEN/CLOSE 버튼 값을 지속적으로 받아온다.
void PIR_Sensor::run()
{
    while(!m_stopFlag)
    {
        gPir = digitalRead(PIR_GPIO_IN);
        gOpenButton = digitalRead(OPEN_BTN_GPIO);
        gCloseButton = digitalRead(CLOSE_BTN_GPIO);

       emit ThreadEnd(gPir);
       sleep(1);
    }
}

uint8_t PIR_Sensor::getPirData()
{
    return _detected;
}

void PIR_Sensor::stop()
{
    m_stopFlag = true;
}
